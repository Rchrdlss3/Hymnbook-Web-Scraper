from bs4 import BeautifulSoup
import requests
###THIS IS JUST FOR THE CHANTE DESPERANCE KREYOL SONGS SO FAR. 
###TOTAL OF 62 PAGES


##USING BEAUTIFUL SOUP AND REQUESTS TO GET THE SOURCE CODE
page_number = 1
##USING A WHILE LOOP TO AGEE THE PAGE NUMBERS INTO THE LINKS,WILL LATER USE
while page_number <= 62:
    new_page = 'http://haitianview.com/category/chants-desperance/page/' + page_number
    page_number +=1
    
html_text = requests.get('http://haitianview.com/category/chants-desperance/').text
soup = BeautifulSoup(html_text,'lxml')

links = []
singles = soup.find_all('a',class_ ='td-image-wrap')

for single in singles:
    x = single['href']
    links.append(x)


#THIS JUST PRINTS ALL THE PAGES SO YOU CAN GET A HINT OF WHATS GOING ON NIGGA
print(links)

##EACH PAGE EXCEPT PAGE 62 HAS 10 SONG LINKS, SO 

#THE LINK OF THE SONG, THEN WILL BE SCRAPED TO GET THE LYRICS
song_link = requests.get(str(links[0])).text


